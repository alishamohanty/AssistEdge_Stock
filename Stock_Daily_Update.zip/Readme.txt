--------------------------Instructions for use---------------------------------------------------------------
-
-
-
-
The application works for predefined set of companies whose shares we want to keep an eye on.
Open a Ms-Excel file and name it as Stock.xlsx and enlist the companies whose stocks we are interested in under the heading Company.
Store other headers as 
   -> BSE_RS (Under this section current BSE values will be stored in Rupees)
   -> BSE_LastUpdate_Date(This will store the dates when the BSE values were last updated)
   -> NSE_RS  (Under this section current NBSE values will be stored in Rupees)
   -> NSE_LastUpdate_Date (This will store the dates when the NSE values were last updated)
----------------------------------------------------------------------------------------------------------------
||		 NOTE: Make sure you don't rename the headers, or else the automation might fail		||
----------------------------------------------------------------------------------------------------------------

-------------------------All rights reserved Alisha Mohanty 2018 ----------------------------------
